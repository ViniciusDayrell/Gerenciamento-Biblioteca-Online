package interfaces;

public interface IDevolucao {
    // Metodo para realizar a devolucao de um livro
    void devolverLivro();

}
