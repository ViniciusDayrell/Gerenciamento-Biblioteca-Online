package interfaces;

public interface IEmprestimo {
    // Metodo para realizar emprestimo do livro
    void realizarEmprestimo();

    // Metodo para cancelar o emprestimo do livro
    void cancelarEmprestimo();
}
